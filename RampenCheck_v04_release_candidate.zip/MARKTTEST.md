# RampenCheck – 14-Tage-Markttest

**Hypothese:** B2B-Versender mit sperrigen Waren würden für die Vermeidung von Entlade-Rückfragen zahlen. Noch unbestätigt.

1. Rechtliche Pflichtangaben ergänzen und Demo veröffentlichen.
2. Einen organischen, regelkonformen Vertriebskanal wählen (z. B. öffentlich zugängliche Shop-App-Verzeichnisse oder eigener fachlicher Website-Beitrag); keine ungefragten Werbe-E-Mails.
3. Qualifizierte Pilotanfragen erfassen, ohne vertrauliche Kundendaten.
4. In Gesprächen Problemhäufigkeit, bestehende Software, Kosten eines Fehlversuchs und Zahlungsbereitschaft prüfen.
5. Erst nach belegtem Bedarf Shop-Integration und Preismodell bauen.

**Go-/No-Go-Kriterien (Arbeitsannahmen):** 5 relevante Rückmeldungen und mindestens 2 Unternehmen, die ein konkretes bezahltes Pilotprojekt diskutieren möchten. Bei 0 Rückmeldungen ist der Vertriebskanal, nicht automatisch die Produktidee, unbewiesen.

**Kein Budget ohne separate Freigabe.**
