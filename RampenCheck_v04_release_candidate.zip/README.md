# RampenCheck – Release Candidate 0.4

Statische Website, keine Serverkomponenten, kein Tracking und keine Datenspeicherung.

## Was funktioniert
- Regelbasierter Check für Paket, Palette, Maschine und Schwertransport
- Abgleich von Gewicht und Tragfähigkeit bei bekannten Angaben
- Hinweise zu Entladung und Lkw-Zufahrt
- PDF-Ausdruck über Browser
- Pilotanfrage öffnet lokal das E-Mail-Programm

## Was ausdrücklich nicht funktioniert
- Keine automatische Shopify-/WooCommerce-Anbindung
- Keine KI-Auswertung des Freitexts
- Keine automatisierte Kundengewinnung, keine Zahlungsabwicklung
- Keine verbindliche technische Freigabe oder Kostenschätzung

## Deployment (manuell)
1. `index.html` in der Wurzel des Repositories `Weltstar1972/rampencheck` ersetzen.
2. GitHub Pages: Branch `main`, Verzeichnis `/ (root)`.
3. Nach Deployment Website mobil testen und Pilotanfrage anklicken.

## Rechtliche Voraussetzung vor aktivem Marketing
Impressum mit ladungsfähiger Anschrift, vertretungsberechtigter Person, Handelsregister und USt-ID soweit zutreffend; Datenschutzhinweise für GitHub Pages und E-Mail-Kommunikation fachlich prüfen. Keine vertraulichen Kundendaten über die Demo einsammeln.

## Erfolgsmessung (manuell, ohne Tracking)
Wöchentliche Zählung eingegangener Pilotanfragen, qualifizierter Gespräche und zahlungsbereiter Interessenten. Keine erfundenen Besucherzahlen.
